<x-guest-layout>

    <div>
        <div class="container mx-auto lg:ml-80 mt-12 mb-12">

            <!-- Heading And Text Area -->
            <div class="space-y-6 font-medium text-justify lg:w-5/12 mb-6 px-6">
                <h1 class="text-xl md:text-4xl font-serif text-gray-700">Contact Eastern Lead Express</h1>

                <h2 class="text-xl md:text-2xl font-sans text-gray-700">
                    Email: <span class="font-serif">easternlead01@gmail.com</span>
                </h2>

                <h2 class="text-base md:text-2xl font-medium	font-sans text-gray-700">
                    Phone: <span class="font-mono ">+234 916 155 6335</span>
                </h2>


                <p class="text-lg  font-sans">
                    Eastern Lead Express is Leading The People ... Moulding Opinions.

                    If you are seeking information or need to places your Advertisement in our platform for the <span
                        class="font-serif text-green-700 font-semibold">Eastern Lead Express</span> website we Offer First
                    Responders offer please contact:
                </p>

            </div>


        </div>
    </div>

</x-guest-layout>
