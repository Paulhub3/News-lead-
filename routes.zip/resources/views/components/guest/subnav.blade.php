<div
    class="left-0 right-0 border-b-2 border-gray-200  bg-white py-3 px-4 border-t-gray-200  mx-auto">

    <!-- MENU ITEMS 1-->
    <div class="flex pl-3 md:ml-44 lg:ml-64">

        <div class="py-3 px-2">
            <h2 class="text-[#d20f26] text-base font-semibold font-sans tracking-tight">Hot Topics</h2>
        </div>


        <marquee width="90%" direction="left" height="50px" class="flex space-x-2">

            <div class=" inline-flex py-3 px-3 space-x-4">

                <h2 class="text-sky-900 text-base font-medium font-sans tracking-tight">
                  Join us on Whatsapp and get News Update's
                </h2>

                <h2 class="text-sky-900 text-base font-medium font-sans tracking-tight">
                    Contact Us For Your Advertisment
                </h2>

            </div>

        </marquee>

    </div>

</div>
